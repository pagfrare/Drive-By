# Drive-By
Projeto de jogo de corrida 2d feito na Godot engine. Inspirado no já encerrado Forever Drive

O jogo é um Endless runner em que ao chegar no checkpoint, sua gasolina é renovada e a dificuldade é aumentada


Projeto para o grupo de estudo Maritacas GameDev
